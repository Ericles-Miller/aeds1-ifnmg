#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "Cliente.h"



int main ()
{
    int n=1;
    mostrar_menu();
    escolher_menu(n);





    return 0;
}
