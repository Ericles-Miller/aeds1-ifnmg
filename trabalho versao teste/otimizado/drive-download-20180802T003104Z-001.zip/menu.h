#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#ifndef MENU_H
#define MENU_H

void mostrar_menu();
void escolher_menu(int opcao);
#endif // MENU_H



