#include <stdio.h>

main ()
{
    int c;

    for(c=1;c<=10;c++)/* c+=1 c=c+1*/
      printf("Oba!!! hoje tem aula de AEDS I %i\n",c);



    return 0;
}
