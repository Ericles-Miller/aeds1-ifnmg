#include <stdio.h>
#include <stdlib.h>


struct aluno
{
    char nome[100];
    int matricula;
    float cr;
};


int main()
{
    struct aluno a1, *pa;

    pa = &a1;
    printf("Digite nome: ");
    scanf("%s", a1.nome);
    printf("Digite matricula: ");
    scanf("%i", &a1.matricula);
    printf("Digite CR: ");
    scanf("%f", &a1.cr);

    printf("Nome: %s\n", a1.nome);
    printf("Matricula: %i\n", a1.matricula);
    printf("CR: %f\n", a1.cr);

    printf("Nome: %s\n", pa->nome);
    printf("Matricula: %i\n", pa->matricula);
    printf("CR: %f\n", pa->cr);







    return 0;
}

