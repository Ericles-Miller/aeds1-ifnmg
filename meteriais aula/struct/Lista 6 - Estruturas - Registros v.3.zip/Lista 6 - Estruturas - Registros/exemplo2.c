#include <stdio.h>
#include <stdlib.h>

typedef struct aluno TAluno;
struct aluno
{
    char nome[100];
    int matricula;
    float cr;
};

typedef int inteiro;

int main()
{
    TAluno a1, *pa;

    printf("Digite nome: ");
    scanf("%s", a1.nome);
    printf("Digite matricula: ");
    scanf("%i", &a1.matricula);
    printf("Digite CR: ");
    scanf("%f", &a1.cr);

    printf("Nome: %s\n", a1.nome);
    printf("Matricula: %i\n", a1.matricula);
    printf("CR: %f\n", a1.cr);

    pa = (TAluno*)malloc(sizeof(TAluno));

    printf("Digite nome: ");
    scanf("%s", pa->nome);
    printf("Digite matricula: ");
    scanf("%i", &pa->matricula);
    printf("Digite CR: ");
    scanf("%f", &pa->cr);

    printf("Nome: %s\n", pa->nome);
    printf("Matricula: %i\n", pa->matricula);
    printf("CR: %f\n", pa->cr);

    free(pa);

    return 0;
}

