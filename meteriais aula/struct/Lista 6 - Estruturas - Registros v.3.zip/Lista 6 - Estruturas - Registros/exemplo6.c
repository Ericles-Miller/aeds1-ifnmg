#include <stdio.h>
#include <stdlib.h>

typedef struct aluno TAluno;
struct aluno
{
    char nome[100];
    int matricula;
    float cr;
};

void ler_aluno( TAluno *p )
{
    printf("Digite nome: ");
    scanf("%s", p->nome);
    printf("Digite matricula: ");
    scanf("%i", &p->matricula);
    printf("Digite CR: ");
    scanf("%f", &p->cr);
}

void imprimir_aluno( TAluno *al )
{
    printf("Nome: %s\n", al->nome);
    printf("Matricula: %i\n", al->matricula);
    printf("CR: %.2f\n", al->cr);
}

#define N 3

int main()
{
    int i;
    TAluno *lista;

    lista = (TAluno*)malloc(sizeof(TAluno)*N);

    for(i=0;i<N;i++)
    {
        ler_aluno( &lista[i] );
    }

    for(i=0;i<N;i++)
    {
        imprimir_aluno(&lista[i]);
    }
    free(lista);
    return 0;
}

