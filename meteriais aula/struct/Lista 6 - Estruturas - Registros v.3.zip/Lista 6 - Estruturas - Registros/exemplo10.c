#include <stdio.h>
#include <stdlib.h>

typedef struct endereco TEndereco;
struct endereco
{
    char rua[30];
    int num;
    char bairro[30];
    char cidade[30];
};

typedef struct aluno TAluno;
struct aluno
{
    char nome[100];
    int matricula;
    float cr;
    TEndereco *end;
    int qtd_end;
};

void ler_endereco(TEndereco *e)
{
    printf("Digite rua: ");
    scanf("%s", e->rua);
    printf("Digite numero: ");
    scanf("%i", &e->num);
    printf("Digite bairro: ");
    scanf("%s", e->bairro);
    printf("Digite cidade: ");
    scanf("%s", e->cidade);
}

void imprimir_endereco(TEndereco *e)
{
    printf("Rua: %s\n", e->rua);
    printf("Numero: %i\n", e->num);
    printf("Bairro: %s\n", e->bairro);
    printf("Cidade: %s", e->cidade);
}

void ler_aluno( TAluno *p )
{
    int i;
    printf("Digite nome: ");
    scanf("%s", p->nome);
    printf("Digite matricula: ");
    scanf("%i", &p->matricula);
    printf("Digite CR: ");
    scanf("%f", &p->cr);

    for(i=0;i<p->qtd_end;i++)
    {
        ler_endereco(&p->end[i]);
    }
}

void imprimir_aluno( TAluno *al )
{
    int i;
    printf("Nome: %s\n", al->nome);
    printf("Matricula: %i\n", al->matricula);
    printf("CR: %.2f\n", al->cr);
        for(i=0;i<al->qtd_end;i++)
        {
          imprimir_endereco(&al->end[i]);
        }

}

int main()
{
    int i;
    TAluno *a;

    a = (TAluno*)malloc(sizeof(TAluno));
    printf("Digite quantidade de enderecos: ");
    scanf("%i", &a->qtd_end);
    a->end = (TEndereco*)malloc(sizeof(TEndereco)*a->qtd_end);
    ler_aluno(a);
    imprimir_aluno(a);
    free(a->end);
    free(a);

    return 0;
}

