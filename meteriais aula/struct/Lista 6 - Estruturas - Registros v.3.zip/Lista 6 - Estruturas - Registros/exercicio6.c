#include <stdio.h>
#include <string.h>

/*
6.	Fa�a um algoritmo que controle contas de banco.
Leia um inteiro n e:
a.	Crie e leia um vetor de contas de banco, com c�digo (inteiro),
 cliente (m�ximo 115 letras), saldo.
b.	Leia um inteiro. Se for lido 1, execute dep�sito.
Se for lido 2, execute saque. Se for lido 3, listar as contas
em ordem crescente(por cliente). Se for 4, imprimir a conta
indicada. Se for lido 0, finalize o programa. Repita este
processo enquanto n�o for lido um valor v�lido.
c.	Dep�sito: leia um c�digo de conta e um valor. Some o valor
lido no saldo da conta lida. Mostre o nome do cliente e o
saldo resultante na tela.
d.	Saque: leia um c�digo de conta e um valor. Se o saldo for
suficiente, deduza o valor lido no saldo da conta lida. Mostre
o nome do cliente e o saldo resultante na tela.
*/
typedef struct conta TConta;
struct conta
{
    int codigo;
    char nome[116];
    float saldo;
};

void ler_conta(TConta *c)
{
    printf("Digite codigo da conta: ");
    scanf("%i", &c->codigo);
    printf("Digite nome do cliente: ");
    scanf("%s",c->nome);
    printf("Digite saldo: ");
    scanf("%f",&c->saldo);
}

void ler_contas(TConta *p, int t)
{
    int i;

    for(i=0; i<t; i++)
    {
        ler_conta(&p[i]);
    }
}

void imprimir_conta(TConta *c)
{
    printf("Codigo da conta: %i\n", c->codigo);
    printf("Nome do cliente: %s\n",c->nome);
    printf("Saldo: %f\n\n", c->saldo);
}

void imprimir_contas(TConta *p, int t)
{
    int i;

    for(i=0; i<t; i++)
    {
        imprimir_conta(&p[i]);
    }
}


TConta * encontrar_conta(int codigo, TConta *p, int t)
{
    int i ;
    for(i=0; i<t; i++)
    {
        if( codigo == p[i].codigo)
        {
            return &p[i];
        }
    }
    return NULL;
}

void deposito(TConta *c, float valor)
{
    c->saldo += valor;
    printf("Cliente: %s\n", c->nome);
    printf("Saldo: %.2f\n", c->saldo);
}

void saque (TConta *c, float valor)
{
    if(c->saldo >= valor)
    {
        c->saldo -= valor;
        printf("Cliente: %s\n", c->nome);
        printf("Saldo: %.2f\n", c->saldo);
    }
    else
    {
        printf("Saldo insuficiente\n");
    }
}

void ordenar_contas(TConta *c, int t)
{
    int i,j;
    TConta aux;

    for(i=0; i<t-1; i++)
    {
        for(j=0; j<t-1; j++)
        {
            if(strcmp(c[j].nome, c[j+1].nome) == 1)
            {
                aux = c[j];
                c[j] = c[j+1];
                c[j+1] = aux;
            }
        }
    }
}


int main()
{
    int n, op, codigo;
    float valor;

    printf("Digite quantidade de contas: ");
    scanf("%i",&n);

    TConta contas[n], *c;
    ler_contas(contas, n);
    ordenar_contas(contas, n);

    do
    {
        printf("\n1 - Deposito\n");
        printf("2 - Saque\n");
        printf("3 - Listar\n");
        printf("4 - Exibir conta\n");
        scanf("%i",&op);
        switch(op)
        {
            case 1:
                    printf("Digite codigo: ");
                    scanf("%i", &codigo);
                    c = encontrar_conta(codigo, contas, n);
                    if( c != NULL)
                    {
                        printf("Digite valor para deposito: ");
                        scanf("%f",&valor);
                        deposito(c, valor);
                    }
                    else
                    {
                        printf("Conta nao encontrada\n");
                    }
                    break;
            case 2:
                    printf("Digite codigo: ");
                    scanf("%i", &codigo);
                    c = encontrar_conta(codigo, contas, n);
                    if( c != NULL)
                    {
                        printf("Digite valor para saque: ");
                        scanf("%f",&valor);
                        saque(c, valor);
                    }
                    else
                    {
                        printf("Conta nao encontrada\n");
                    }
                    break;
            case 3:
                    imprimir_contas(contas, n);
                    break;
            case 4:
                    printf("Digite codigo: ");
                    scanf("%i", &codigo);
                    c = encontrar_conta(codigo, contas, n);
                    if( c != NULL)
                    {
                        imprimir_conta(c);
                    }
                    else
                    {
                        printf("Conta nao encontrada\n");
                    }
                    break;
            default:
                printf("Operacao invalida\n");

        }
    }while( op != 0);


    return 0;
}
