#include <stdio.h>
#include <stdlib.h>

/*
O IFNMG campus  Montes Claro deseja automatizar a organiza��o de professores,
disciplinas, alunos. � necess�rio armazenar no sistema acad�mico as seguintes
informa��es:
�	Para professor: nome e curso de forma��o;
�	Para aluno: nome, matr�cula, sexo, lista de disciplinas cursadas, lista de
 medias das disciplinas cursadas;
�	Para disciplina: sigla, nome, professor, carga hor�ria;
a)	Construa estruturas de dados para representar a descri��o do sistema
acad�mico.
b)	Crie uma fun��o para alocar um aluno. Todos os dados necess�rios para a
aloca��o devem ser passados por par�metros. A fun��o deve retornar a aloca��o
 do aluno sem qualquer pend�ncia de aloca��o.
c)	Crie uma fun��o para ler um aluno. Todas as informa��es para preencher um
 aluno devem ser lidas dentro da fun��o. Obs.: printf n�o � obrigat�rio.
d)	Crie uma fun��o que receba um aluno como par�metro e calcule a m�dia
obtida em todas as disciplinas.
e)	Crie uma fun��o que receba como par�metro uma lista de alunos, seu
tamanho e uma matr�cula M. A fun��o deve pesquisa o aluno de matr�cula M e
exibir todos os seus professores.
*/

typedef struct professor TProfessor;
struct professor
{
    char nome[50];
    char formacao[30];
};

typedef struct disciplina TDisciplina;
struct disciplina
{
    char sigla[5];
    char nome[30];
    TProfessor *prof;
    int carga_horaria;
};

typedef struct aluno TAluno;
struct aluno
{
    char nome[40];
    int matricula;
    char sexo;
    int qtd_disc;
    TDisciplina *lista_disc;
    float *medias;
};

void ler_professor( TProfessor *p)
{
    printf("Digite nome do professor: ");
    scanf("%s", p->nome);
    printf("Digite formacao do professor: ");
    scanf("%s", p->formacao);
}

void imprimir_professor( TProfessor *p)
{
    printf("Nome do professor: %s\n", p->nome);
    printf("Formacao do professor: %s\n", p->formacao);
}

void ler_disciplina(TDisciplina *d)
{
    printf("Digite sigla: ");
    scanf("%s", d->sigla);
    printf("Digite nome da disciplina: ");
    scanf("%s", d->nome);
    printf("Digite carga horaria: ");
    scanf("%i", &d->carga_horaria);
    d->prof = (TProfessor*)malloc(sizeof(TProfessor));
    ler_professor(d->prof);
}

void imprimir_disciplina(TDisciplina *d)
{
    printf("Sigla: %s\n", d->sigla);
    printf("Nome da disciplina: %s\n", d->nome);
    printf("Carga horaria: %i\n", d->carga_horaria);
    imprimir_professor(d->prof);
}

void ler_aluno(TAluno *a)
{
    int i ;
    printf("Digite nome do aluno: ");
    scanf("%s", a->nome);
    printf("Digite matricula do aluno: ");
    scanf("%i", &a->matricula);
    printf("Digite sexo do aluno: ");
    scanf("\n%c", &a->sexo);
    printf("Digite quantidade de disciplinas: ");
    scanf("%i", &a->qtd_disc);
    a->medias = (float*)malloc(sizeof(float) * a->qtd_disc);
    a->lista_disc = (TDisciplina*)malloc(sizeof(TDisciplina) * a->qtd_disc);
    for(i=0;i<a->qtd_disc;i++)
    {
        ler_disciplina(&a->lista_disc[i] );
        printf("Digite media: ");
        scanf("%f",&a->medias[i]);
    }
}

void imprimir_aluno(TAluno *a)
{
    int i ;
    printf("Nome do aluno: %s\n", a->nome);
    printf("Matricula do aluno: %i\n", a->matricula);
    printf("Sexo do aluno: %c\n", a->sexo);
    for(i=0;i<a->qtd_disc;i++)
    {
        imprimir_disciplina( &a->lista_disc[i] );
        printf("Media: %f\n",a->medias[i]);
    }
    printf("\n");
}

#define N 1

int main()
{
    int a,d;
    TAluno *lista = (TAluno*)malloc(sizeof(TAluno) * N);
    for(a=0; a<N; a++)
    {
        ler_aluno( &lista[a]);
    }

    for(a=0; a<N; a++)
    {
        imprimir_aluno( &lista[a]);
    }

    for(a=0; a<N; a++)
    {
        for(d=0; d<lista[a].qtd_disc; d++)
        {
            /* desaloco professor de cada disciplina */
            free(lista[a].lista_disc[d].prof);
        }
        /* desaloco lista disciplinas */
        free(lista[a].lista_disc);

        /* desaloco medias */
        free(lista[a].medias);
    }
    /* desaloco lista de alunos */
    free(lista);

    return 0;
}
