#include <stdio.h>
#include <stdlib.h>

typedef struct aluno TAluno;
struct aluno
{
    char nome[100];
    int matricula;
    float cr;
};

void ler_aluno( TAluno *p )
{
    printf("Digite nome: ");
    scanf("%s", p->nome);
    printf("Digite matricula: ");
    scanf("%i", &p->matricula);
    printf("Digite CR: ");
    scanf("%f", &p->cr);
}

void imprimir_aluno( TAluno *al )
{
    printf("Nome: %s\n", al->nome);
    printf("Matricula: %i\n", al->matricula);
    printf("CR: %f\n", al->cr);
}

int main()
{
    TAluno *a;

    a = (TAluno*)malloc(sizeof(TAluno));
    ler_aluno(a);
    imprimir_aluno(a);
    free(a);
    return 0;
}

