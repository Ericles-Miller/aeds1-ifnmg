#include <stdio.h>

main ()
{
    int c,i=1;

    for(c=-20;c>=-29;c--)
      printf("Oba!!! hoje tem aula de AEDS I %i\n",i++);



    return 0;
}
