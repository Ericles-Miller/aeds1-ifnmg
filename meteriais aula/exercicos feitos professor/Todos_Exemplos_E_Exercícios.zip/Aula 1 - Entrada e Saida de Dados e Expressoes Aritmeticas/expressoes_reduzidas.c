#include <stdio.h>

int main()
{
    int a = 9, b = 5, w;
    /*w = a++ + b + a;
    printf("Valor a: %i\n", w);
    */

    /*w = a + b + a++;
    printf("Valor a: %i\n", w);
    */

    /*
    w = a + b + ++a;
    printf("Valor a: %i\n", w);
    */

    /*
    w = ++a + b + a;
    printf("Valor a: %i\n", w);
    */



    return 0;
}
