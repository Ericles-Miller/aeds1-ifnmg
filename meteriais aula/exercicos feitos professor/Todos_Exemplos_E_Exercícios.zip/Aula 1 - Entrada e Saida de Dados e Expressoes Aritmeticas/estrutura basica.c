#include <stdio.h>

int main()
{

    printf("Algoritmos e estrutura de dados I\n");
    printf("\nCaribe Zampirolli de Souza");


    return 0;
}
