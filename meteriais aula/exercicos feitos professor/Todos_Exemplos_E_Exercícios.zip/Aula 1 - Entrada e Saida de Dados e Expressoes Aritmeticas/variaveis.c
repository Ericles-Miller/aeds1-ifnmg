#include <stdio.h>

int main()
{
    int idadecaribe,idadegabriel;
    char categoria;
    float valor;




    return 0;
}
