#include <stdio.h>

int main()
{
    int n1,n2,r;
    printf("Digite dois valores: ");
    scanf("%i %i",&n1,&n2);
    r = n1 + n2;
    printf("Soma: %i\n",r);
    return 0;
}
