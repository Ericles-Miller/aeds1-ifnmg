
#ifndef ENDERECO_H
#define ENDERECO_H

typedef struct endereco TEndereco;
struct endereco
{
    char rua[30];
    int numero;
    char bairro[30];
};

void ler_endereco(TEndereco *e);
void imprimir_endereco(TEndereco *e);

#endif // ENDERECO_H

