
#ifndef CONTA_H
#define CONTA_H

typedef struct conta TConta;
struct conta
{
    int codigo;
    int ag;
    int conta;
    float saldo;
};

void ler_conta( TConta *c);
void imprimir_conta( TConta *c);

void gravar_conta( TConta *c);
TConta * buscar_conta(int ag, int conta);
void imprimir_conta_cliente( int codigo);


#endif // CONTA_H
