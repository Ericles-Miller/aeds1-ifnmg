#include "endereco.h"
#include <stdio.h>

void ler_endereco(TEndereco *e)
{
    printf("Digite rua: ");
    scanf("%s", e->rua);
    printf("Digite numero: ");
    scanf("%i", &e->numero);
    printf("Digite bairro: ");
    scanf("%s", e->bairro);
}

void imprimir_endereco(TEndereco *e)
{
    printf("Rua: %s\n", e->rua);
    printf("Numero: %i\n", e->numero);
    printf("Bairro: %s\n\n", e->bairro);
}
