#include <stdio.h>
#include <stdlib.h>
#include "cliente.h"

int main()
{
    TCliente c, *pc;

    printf("Ler dados cliente:\n");
    ler_cliente( &c );
    printf("Gravar dados cliente:\n");
    gravar_cliente(&c);

    printf("Ler dados cliente:\n");
    ler_cliente( &c );
    printf("Gravar dados cliente:\n");
    gravar_cliente(&c);

    printf("Ler dados cliente:\n");
    ler_cliente( &c );
    printf("Gravar dados cliente:\n");
    gravar_cliente(&c);

    printf("Buscar cliente:\n");
    pc = buscar_cliente(2);

    printf("Digite novo telefone: ");
    scanf("%s",pc->telefone);

    alterar_cliente(pc);

    //printf("Imprimir dados cliente:\n");
    //imprimir_cliente( pc );

    printf("Listar clientes:\n");
    imprimir_registro_cliente();

    free(pc);
    return 0;
}
