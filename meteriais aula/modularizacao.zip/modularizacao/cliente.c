#include "cliente.h"
#include "endereco.h"
#include <stdio.h>
#include <stdlib.h>

void ler_cliente( TCliente *c)
{
    printf("Digite codigo do cliente: ");
    scanf("%i", &c->codigo);
    printf("Digite nome: ");
    scanf("%s", c->nome);
    printf("Digite telefone: ");
    scanf("%s", c->telefone);
    ler_endereco(&c->end);
    /*printf("Digite quantidade de contas: ");
    scanf("%i", &c->qtd_contas);
    c->contas = (TConta*)malloc(sizeof(TConta)*c->qtd_contas);
    for(i=0;i<c->qtd_contas;i++)
    {
        ler_conta(&c->contas[i]);
    }*/
}

void imprimir_cliente( TCliente *c)
{
    //int i;
    printf("Nome: %s\n", c->nome);
    printf("Telefone: %s\n", c->telefone);
    imprimir_endereco(&c->end);
    /*for(i=0;i<c->qtd_contas;i++)
    {
        imprimir_conta(&c->contas[i]);
    }*/
}

void gravar_cliente( TCliente *c)
{
    FILE *pa;

    if( (pa = fopen("cliente", "a+b")) == NULL)
    {
        printf("ERRO ARQUIVO\n");
    }
    else
    {
        fwrite( c, sizeof(TCliente), 1, pa);
        fclose(pa);
    }
}

TCliente * buscar_cliente(int codigo)
{
    TCliente *c = (TCliente*)malloc(sizeof(TCliente));
    FILE *pa;

    if( (pa = fopen("cliente", "rb")) == NULL)
    {
        printf("ERRO ARQUIVO\n");
    }
    else
    {
        while(!feof(pa))
        {
            fread( c, sizeof(TCliente), 1, pa);
            if( c->codigo == codigo)
            {
                fclose(pa);
                return c;
            }
        }
        fclose(pa);
    }
    return NULL;
}

void imprimir_registro_cliente( )
{
    TCliente *c = (TCliente*)malloc(sizeof(TCliente));
    FILE *pa;

    if( (pa = fopen("cliente", "rb")) == NULL)
    {
        printf("ERRO ARQUIVO\n");
    }
    else
    {
        while(!feof(pa))
        {
            if( fread( c, sizeof(TCliente), 1, pa) == 1)
            {
                imprimir_cliente(c);
            }
        }
        fclose(pa);
    }
    free(c);
    return NULL;
}

void alterar_cliente(TCliente *c)
{
    FILE *pa;
    TCliente cli;

    if((pa = fopen("cliente","r+b")) == NULL)
    {
        printf("ERROR - ARQUIVO\n");
    }
    else
    {
        while(!feof(pa))
        {
            if( fread(&cli, sizeof(TCliente),1, pa) == 1)
            {
                if( cli.codigo == c->codigo)
                {
                    fseek(pa, -sizeof(TCliente), SEEK_CUR);
                    fwrite(c, sizeof(TCliente),1, pa);
                    break;
                }
            }
        }
        fclose(pa);
    }
}


