#include "conta.h"
#include <stdio.h>

void ler_conta( TConta *c)
{
    printf("Digite codigo do cliente: ");
    scanf("%i", &c->codigo);
    printf("Digite agencia: ");
    scanf("%i", &c->ag);
    printf("Digite conta: ");
    scanf("%i", &c->conta);
    printf("Digite saldo: ");
    scanf("%f", &c->saldo);
}

void imprimir_conta( TConta *c)
{
    printf("Codigo do cliente: %i\n", c->codigo);
    printf("Agencia: %i\n", c->ag);
    printf("Conta: %i\n", c->conta);
    printf("Saldo: %f\n\n", c->saldo);
}

void gravar_conta( TConta *c)
{
    FILE *pa;

    if( (pa = fopen("conta", "a+b")) == NULL)
    {
        printf("ERROR - ARQUIVO\n");
    }
    else
    {
        fwrite(c,sizeof(TConta),1,pa);
        fclose(pa);
    }
}

TConta * buscar_conta(int ag, int conta)
{
    FILE *pa;
    TConta *c = (TConta*)malloc(sizeof(TConta));

    if( (pa = fopen("conta", "rb")) == NULL)
    {
        printf("ERROR - ARQUIVO\n");
    }
    else
    {
        while(!feof(pa))
        {
            fread(c,sizeof(TConta),1,pa);
            if(c->ag == ag && c->conta == conta)
            {
                fclose(pa);
                return c;
            }
        }
        fclose(pa);
    }
    return NULL;
}

void imprimir_conta_cliente( int codigo)
{
    TConta conta;
    FILE *pa;

    if( (pa = fopen("cconta", "rb")) == NULL)
    {
        printf("ERROR - ARQUIVO\n");
    }
    else
    {
        while(!feof(pa))
        {
            fread(&conta, sizeof(TConta),1,pa);
            if(conta.codigo == codigo )
            {
                imprimir_conta(&conta);
            }
        }
        fclose(pa);
    }
}

