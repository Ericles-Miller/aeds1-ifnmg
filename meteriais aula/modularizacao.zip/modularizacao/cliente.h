#include "endereco.h"
#include "conta.h"

#ifndef CLIENTE_H
#define CLIENTE_H

typedef struct cliente TCliente;
struct cliente
{
    int codigo;
    char nome[30];
    char telefone[20];
    TEndereco end;
};[

 ]

void ler_cliente( TCliente *c);
void imprimir_cliente( TCliente *c);
void gravar_cliente( TCliente *c);
TCliente * buscar_cliente(int codigo);
void imprimir_registro_cliente();
void alterar_cliente(TCliente *c);

#endif // CLIENTE_H

