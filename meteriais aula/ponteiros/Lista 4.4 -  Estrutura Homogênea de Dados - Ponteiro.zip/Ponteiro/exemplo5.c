#include <stdio.h>

int main()
{
    int *vet = NULL;
    char *lista = NULL;

    vet = (int *)malloc(sizeof(int) * 10);
    lista = (char*)malloc(sizeof(char)*10);



    return 0;
}
